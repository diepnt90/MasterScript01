// ===== Helper: lấy và chuẩn hoá resourceId từ URL Azure Portal =====
function parseAzureResourceFromUrl(urlStr) {
  let subid = "", appplan = "", webapp = "", slot = "", kind = ""; // kind: sites|serverfarms
  try {
    const u = new URL(urlStr);
    const hash = u.hash || "";

    let resourceIdDecoded = "";

    // 1) Case plaintext: ...#@tenant/resource/subscriptions/...
    const mPlain = hash.match(/\/resource(\/subscriptions\/[^?#]+)/i);
    if (mPlain && mPlain[1]) {
      resourceIdDecoded = mPlain[1];
    } else {
      // 2) Case Metrics: .../ResourceId/%2Fsubscriptions%2F...
      const mEnc = hash.match(/ResourceId\/([^/]+)(?=\/|$)/i);
      if (mEnc && mEnc[1]) {
        resourceIdDecoded = decodeURIComponent(mEnc[1]);
      } else {
        // 3) Fallback: decode toàn bộ hash rồi tìm lại
        try {
          const decodedHash = decodeURIComponent(hash);
          const mAny = decodedHash.match(/\/subscriptions\/[^?#]+/i);
          if (mAny) resourceIdDecoded = mAny[0];
        } catch (_) { /* ignore */ }
      }
    }

    // 3.b) CẮT đuôi dư (appServices, TimeContext~/..., Chart~/..., …)
    if (resourceIdDecoded) {
      const baseMatch = resourceIdDecoded.match(
        /(\/subscriptions\/[^/]+\/resourceGroups\/[^/]+\/providers\/Microsoft\.Web\/(?:sites|serverfarms)\/[^/]+(?:\/slots\/[^/]+)?)/i
      );
      if (baseMatch) {
        resourceIdDecoded = baseMatch[1];
      }
    }

    // 4) Parse resourceId đã chuẩn hoá
    if (resourceIdDecoded) {
      const m = resourceIdDecoded.match(
        /^\/subscriptions\/([^/]+)\/resourceGroups\/([^/]+)\/providers\/Microsoft\.Web\/(sites|serverfarms)\/([^/]+)(?:\/slots\/([^/]+))?$/i
      );
      if (m) {
        subid   = m[1];
        appplan = m[2];     // Resource Group
        kind    = m[3];     // 'sites' | 'serverfarms'
        webapp  = m[4];     // tên site hoặc app service plan
        slot    = m[5] || "";
      }
    }

    // 5) Fallback nếu vẫn rỗng
    if (!subid) {
      const m2 = urlStr.match(
        /%2Fsubscriptions%2F([^/%]+)%2FresourceGroups%2F([^/%]+)%2Fproviders%2FMicrosoft\.Web%2F(sites|serverfarms)%2F([^/%]+)(?:%2Fslots%2F([^/%]+))?/i
      );
      if (m2) {
        subid   = m2[1];
        appplan = m2[2];
        kind    = m2[3];
        webapp  = m2[4];
        slot    = m2[5] || "";
      }
    }
  } catch (_) {}
  return { subid, appplan, webapp, slot, kind };
}

// ===== Helper: ép consoleUrl về đúng SCM host của slot =====
// Slot dùng host dạng {site}-{slot}.scm.azurewebsites.net, phòng khi API trả về host production.
function slotAwareConsoleUrl(consoleUrl, webapp, slot) {
  if (!consoleUrl || !slot) return consoleUrl;
  try {
    const u = new URL(consoleUrl);
    const prodPrefix = `${webapp}.`.toLowerCase();
    if (u.hostname.toLowerCase().startsWith(prodPrefix)) {
      u.hostname = `${webapp}-${slot}${u.hostname.slice(webapp.length)}`;
      return u.toString();
    }
  } catch (_) { /* ignore */ }
  return consoleUrl;
}

// ===== Helper: hiện thông báo trong panel =====
// Không dùng alert() vì Chrome chặn alert() trong iframe cross-origin (panel nhúng trong Azure Portal).
function notify(message, kind) {
  const el = document.getElementById("notice");
  if (!el) return;
  el.textContent = message;
  el.className = kind === "ok" ? "ok" : "";
  el.hidden = false;
}

// ===== Main logic =====
chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  var url = (tabs && tabs[0] && tabs[0].url) ? tabs[0].url : "";
  var { subid, appplan, webapp, slot, kind } = parseAzureResourceFromUrl(url);

  if (!subid || !appplan || !webapp) {
    notify("Không lấy được ResourceId từ URL hiện tại. Hãy mở trang resource (Response Time chart hoặc blade resource) rồi thử lại.");
    return;
  }

  chrome.action.getBadgeText({}, function (result) {
    if (!result.includes("Bearer")) {
      notify("Please refresh the tab and go to the response time chart first to get the extension working.");
      return;
    }

    // Cập nhật UI
    const subidElement = document.getElementById("subid");
    subidElement.textContent = `Subscription ID: ${subid}`;
    const appplanElement = document.getElementById("appplan");
    appplanElement.textContent = `App Plan: ${appplan}`;
    const webappElement = document.getElementById("webapp");
    webappElement.textContent = slot ? `Web App: ${webapp} (slot: ${slot})` : `Web App: ${webapp}`;

    // Resource path của site: có slot thì trỏ vào slot, không thì production
    const sitePath = `/subscriptions/${subid}/resourceGroups/${appplan}/providers/Microsoft.Web/sites/${webapp}`
      + (slot ? `/slots/${slot}` : "");

    const dropdownElement = document.getElementById("machine-names");
    const replaceButton = document.getElementById("replace-button");
    const goToKuduButton = document.getElementById("go-to-kudu-button");
    const takeTrace = document.getElementById("take-trace");
    const takeDump = document.getElementById("take-dump");
    const masterScript = document.getElementById("master-script");
    const logFiles = document.getElementById("log-files");
    const aiQuery = document.getElementById("ai-query");
    const threadPool = document.getElementById("threadpool-script");

    // Gọi API lấy danh sách instance
    fetch(`https://management.azure.com${sitePath}/instances?api-version=2020-12-01`, {
      headers: {
        'Authorization': result,
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(data => {
      const machineNames = (data.value || []).map(instance => instance.properties.machineName);
      machineNames.forEach(name => {
        const option = document.createElement('option');
        option.text = name;
        dropdownElement.appendChild(option);
      });

      // ===== Các button event listeners =====
      replaceButton.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          fetch(`https://management.azure.com/subscriptions/${subid}/resourceGroups/${appplan}/providers/Microsoft.Web/serverfarms/${webapp}/workers/${selectedMachineName}/reboot?api-version=2022-03-01`, {
            method: "POST",
            headers: {
              'Authorization': result,
              'Content-Type': 'application/json'
            }
          })
          .then(response => {
            if (response.status >= 200 && response.status < 300) {
              notify(`Machine ${selectedMachineName} is replaced.`, "ok");
            } else {
              response.text().then(error => {
                notify(`Error replacing machine ${selectedMachineName}: ${error}`);
              });
            }
          })
          .catch(error => {
            console.error('Error replacing machine:', error);
          });
        } else {
          notify("Please select a machine to replace.");
        }
      });

      goToKuduButton.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            let kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host", "newui/env");
            if (kuduUrl.includes('?')) kuduUrl += '&hideSecrets=false';
            else kuduUrl += '?hideSecrets=false';
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

      aiQuery.addEventListener("click", function () {
        const resourceUrl = `https://portal.azure.com/#@episerver.net/resource/subscriptions/${subid}/resourceGroups/${appplan}/providers/microsoft.insights/components/${webapp}/logs`;
        const scriptText = `//Top domain query
requests
| extend urlParts = parseurl(url)
| extend hostname = urlParts.Host
| summarize sum(itemCount) by tostring(hostname), bin(timestamp, 1m)
| render timechart

//List requests by time
requests
| where timestamp > datetime(2025-03-31T11:00:00) and timestamp < datetime(2025-03-31T12:00:00) and name !contains "bus"
| project timestamp, id, name, url, performanceBucket, resultCode, cloud_RoleInstance
| sort by timestamp asc

//Check abnormal operation
requests
| where timestamp > datetime(2024-03-25T16:00:00) and timestamp < datetime(2024-03-25T17:00:00)
| summarize sum(itemCount) by operation_Name, bin(timestamp, 1m)
| render timechart

//View operation by columnchart
requests
| where timestamp > datetime(2025-03-31T11:00:00) and timestamp < datetime(2025-03-31T12:00:00) and name !contains "bus"
| top-nested 100 of bin(timestamp, 1m) by count(),
top-nested 10 of name by sum(itemCount)
| project timestamp, name, c=aggregated_name
| order by timestamp asc
| render columnchart`;
        const tempInput = document.createElement("textarea");
        tempInput.value = scriptText;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
        chrome.tabs.create({ url: resourceUrl });
      });

      // ---- takeTrace ----
      takeTrace.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            const kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host?instance=", "ssh?target=app&instance=");
            const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/getdumptrace/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh --trace";
            const tempInput = document.createElement("textarea");
            tempInput.value = scriptText;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

      // ---- takeDump ----
      takeDump.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            const kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host?instance=", "ssh?target=app&instance=");
            const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/getdumptrace/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh --dump";
            const tempInput = document.createElement("textarea");
            tempInput.value = scriptText;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

      // ---- masterScript ----
      masterScript.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            const kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host?instance=", "ssh?target=app&instance=");
            const scriptText = "curl -o script.sh https://raw.githubusercontent.com/diepnt90/MasterScript01/refs/heads/main/script.sh && chmod +x script.sh && ./script.sh";
            const tempInput = document.createElement("textarea");
            tempInput.value = scriptText;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

      // ---- threadPool ----
      threadPool.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            const kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host?instance=", "ssh?target=app&instance=");
            const scriptText = "curl -o Threadpool_script.sh https://raw.githubusercontent.com/diepnt90/threadpoolscript/refs/heads/main/Threadpool_script.sh && chmod +x Threadpool_script.sh && ./Threadpool_script.sh";
            const tempInput = document.createElement("textarea");
            tempInput.value = scriptText;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

      // ---- logFiles (giữ nguyên để bạn đang dùng OK) ----
      logFiles.addEventListener("click", function () {
        const selectedMachineName = dropdownElement.value;
        if (selectedMachineName) {
          const instance = (data.value || []).find(x => x.properties && x.properties.machineName === selectedMachineName);
          if (instance && instance.properties.consoleUrl) {
            let kuduUrl = slotAwareConsoleUrl(instance.properties.consoleUrl, webapp, slot).replace("webssh/host", "api/zip/LogFiles/");
            chrome.tabs.create({ url: kuduUrl });
          } else {
            notify(`Console URL not found for machine ${selectedMachineName}`);
          }
        } else {
          notify("Please select a machine.");
        }
      });

    })
    .catch(error => {
      console.error('Error fetching machine names:', error);
    });
  });
});
